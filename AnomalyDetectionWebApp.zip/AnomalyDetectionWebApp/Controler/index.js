/*
using express package. To load it, in terminal write:
npm init --yes
npm i express
npm i express-fileupload
*/

const algorithm = require('../Model/build/Release/algorithm')
const express = require("express")
const fileUpload = require("express-fileupload")

const app = express()
app.use(express.urlencoded({
    extended: false
}));

app.use(fileUpload());


app.use(express.static('../View'))

app.get("/",(req,res)=>{
    res.sendFile(path.join(__dirname, '../View', 'index.html'));

});

app.post("/detect",(req,res)=>{
    //res.write("Algorithm chosen is "+req.body.algorithm+"\n")
    var CSVtrain = req.files.CSVfile1
    var CSVtest = req.files.CSVfile2
    var algo = req.body.algorithm
    var uploadPath1 = __dirname+'/../Model/'+CSVtrain.name;
    CSVtrain.mv(uploadPath1, function(err) {
        if (err)
            return res.status(500).send(err);
        var uploadPath2 = __dirname+'/../Model/'+CSVtest.name;
        CSVtest.mv(uploadPath2, function(err) {
            if (err)
                return res.status(500).send(err);
            //res.write("CSVfile1 is: "+CSVtrain.name+"\n")
            //res.write("CSVfile2 is: "+CSVtest.name+"\n")
            var response = algorithm.detect(algo,uploadPath1,uploadPath2);
            response=response.replace(/, *\]/,"]");
            response=JSON.parse(response);
            console.log(response);
            console.log(typeof(response));
            res.json(response);
            res.end()
            //console.log(CSVtrain.name,CSVtest.name);
        });
    });
});


app.listen(8080,()=>console.log("server started on port 8080"));