#include "SimpleAnomalyDetector.h"

SimpleAnomalyDetector::SimpleAnomalyDetector() {}

SimpleAnomalyDetector::~SimpleAnomalyDetector() {}

void SimpleAnomalyDetector::learnNormal(const TimeSeries &ts) {
    int length = ts.listSize();
    int features = ts.numOfCol();
    float corrlation;
    int index;
    const double threshold = 0.5;
    for (int i = 0; i < features; ++i) {
        float last = 0;
        float *line1 = ts.getLine(i);
        for (int j = i+1 ; j < features; ++j) {
            float *line2 = ts.getLine(j);
            corrlation = abs(pearson(line1, line2, length));
            free(line2);
            if (corrlation > threshold && corrlation > last) {
                last = corrlation;
                index = j;
            }
        }
        if (last>0){
            string name1 = ts.getColname(i);
            string name2 = ts.getColname(index);
            correlatedFeatures c = correlatedFeatures{name1,name2,last};
            this->cf.push_back(c);
        }
        free(line1);
    }
    //initilaze the line reg
    for (int i = 0; i < this->cf.size(); ++i) {
        int feature1 = ts.indexByName(this->cf.at(i).feature1);
        int feature2 = ts.indexByName(this->cf.at(i).feature2);
        Point** pPoint= ts.makePoint(feature1,feature2);
        float max=0;
        Line l;
        l = linear_reg(pPoint,length);
        this->cf.at(i).lin_reg = l;
        for (int j = 0; j < length; ++j) {
            float corr = dev(Point(pPoint[j]->x,pPoint[j]->y),l);
            if(corr>max){
                max = corr;
            }
        }
        this->cf.at(i).threshold = max;
        ts.deletePoints(pPoint);
    }
}

vector<AnomalyReport> SimpleAnomalyDetector::detect(const TimeSeries &ts) {
    int length = ts.listSize();
    int features = ts.numOfCol();
    vector<AnomalyReport> reporter;
    for (int i = 0; i <this->cf.size(); ++i) {
        int feature1 = ts.indexByName(this->cf.at(i).feature1);
        int feature2 = ts.indexByName(this->cf.at(i).feature2);
        Point** pPoint = ts.makePoint(feature1,feature2);
        for (int j = 0; j < length; ++j) {
            if(dev(*pPoint[j],this->cf.at(i).lin_reg)> this->cf.at(i).threshold*1.2){
                const string description = this->cf.at(i).feature1 + "-" +this->cf.at(i).feature2;
                reporter.push_back(AnomalyReport(description,j+1));
            }
        }
    }
    return reporter;
}