
#include <iostream>
#include <vector>
#include "HybridAnomalyDetector.cpp"
#include "timeseries.cpp"
#include "SimpleAnomalyDetector.cpp"
#include "anomaly_detection_util.cpp"
#include "minCircle.cpp"
#include <fstream>
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
#include <math.h>
#include <string>
#include <node.h>


//just put in all these usings, they're for node to use.
namespace whateverNamespace {
    using v8::Context;
    using v8::Function;
    using v8::FunctionCallbackInfo;
    using v8::FunctionTemplate;
    using v8::Isolate;
    using v8::Local;
    using v8::Number;
    using v8::Object;
    using v8::Persistent;
    using v8::String;
    using v8::Value;
    using v8::Array;
    using v8::Exception;
    using namespace std; //for the strings

    void detect(const FunctionCallbackInfo<Value>&args){
        Isolate* isolate = args.GetIsolate();
        //args
        string algo = *v8::String::Utf8Value(args[0]);
        string trainCsv = *v8::String::Utf8Value(args[1]);
        string testCsv = *v8::String::Utf8Value(args[2]);
        // Csv Files
        TimeSeries ts(trainCsv.c_str());
        TimeSeries ts2(testCsv.c_str());
        //detector
        SimpleAnomalyDetector* ad = algo=="Hybrid"?new HybridAnomalyDetector():new SimpleAnomalyDetector();
        ad->learnNormal(ts);
        vector<correlatedFeatures> cf=ad->getNormalModel();
        vector<AnomalyReport> r = ad->detect(ts2);
        string response="[";
        string str;             
        for (size_t i = 0; i < r.size(); i++)
        {
            str=r.at(i).description;
            response+="{\"description\":\""+str+"\",\"timeStep\":\""+to_string(r.at(i).timeStep)+"\"}, ";
        }
        response+="]";

        args.GetReturnValue().Set(String::NewFromUtf8(isolate, response.c_str()));
        
    }

    void Initialize(Local<Object> exports) {
        NODE_SET_METHOD(exports, "detect", detect);
    }

    NODE_MODULE(NODE_GYP_MODULE_NAME, Initialize); 

}
