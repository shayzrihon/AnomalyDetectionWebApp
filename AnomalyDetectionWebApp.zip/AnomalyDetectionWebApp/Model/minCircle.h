
#include <random>
#include <iterator>
#include <iostream>
#include "anomaly_detection_util.h"
using namespace std;


class Circle {
public:
    Point center;
    float radius;

    Circle(Point c, float r) : center(c), radius(r) {}
};


Circle welzl(Point **&P, vector<Point> R, int size);

Circle findMinCircle(Point **&points, int size);

Circle trivialCircle(vector<Point> R);

bool isInside(Circle &D, Point &p) ;

Circle welzl(Point **&points, vector<Point> R, int size);

Point findMiddle(Point &p1, Point &p2);

float findDistance(Point &p1, Point &p2);

Circle corectCircle3points(Point &p1, Point &p2, Point &p3);

Circle trivialCircle(vector<Point> R);
