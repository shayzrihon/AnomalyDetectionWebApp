
#include <algorithm>
#include <map>
#include <vector>
#include <string>
#include "anomaly_detection_util.h"

#ifndef TIMESERIES_H_
#define TIMESERIES_H_

using namespace std;

class TimeSeries{
    vector<pair<string,vector<float>>> dataList;
public:

    TimeSeries(const char* CSVfileName);
    ~TimeSeries();
    float* getLine(int index)const;
    int numOfCol()const;
    int listSize()const;
    Point** makePoint(int feature1,int feature2)const;
    void deletePoints(Point** pPoint)const;
    string getColname(int column)const;
    void freeArray(float* line)const;
    int indexByName(string feature)const;

};



#endif /* TIMESERIES_H_ */